﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Variables
    {
        static void Main()
        {
            int a = 10;
            double basic = 61.35;
            string name = "Rajesh";
            Console.WriteLine("Value of a:" +a);
            Console.WriteLine("My Basic: " +basic);
            Console.WriteLine("My name: " + name);
        }
    }
}
