﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Employ
    {
        public int empno;
        public string name;
        public double basic;
    }
}
