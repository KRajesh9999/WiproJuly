﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class custom
    {
        static void Main()
        {
            string name;
            Console.WriteLine("Enter Your Name   ");
            name = Console.ReadLine();
            Console.WriteLine("Name is  " + name);
        }
    }
}
