﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorld
{
    internal class Quiz2
    {
        static void Main()
        {
            double rollno = 86779;
            int height = 160;
            Console.WriteLine("5" + 3 + 8); //538
            Console.WriteLine("5" + (3 + 8)); // 511
            Console.WriteLine("5 + 3" + 8); // 5+38
            Console.WriteLine("Rajesh 'rollno': {0} and his height : {1}", rollno, height);
        }
    }
}
