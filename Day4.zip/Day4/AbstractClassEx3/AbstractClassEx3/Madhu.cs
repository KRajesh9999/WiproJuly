﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractClassEx3
{
    internal class Madhu : Employ
    {
        public Madhu(int empno, string name, double basic) : base(empno, name, basic)
        {

        }
    }
}
