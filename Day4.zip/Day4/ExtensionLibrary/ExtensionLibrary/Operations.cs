﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionLibrary
{
    public class Operations
    {
        public string MileStone1()
        {
            return "MileStone1 is on core concepts..";
        }
        public string MileStone2()
        {
            return "MileStone2 is on Asp.net MVC and Rajor...";
        }
    }
}
