﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceClassEx2
{
    internal class InterfaceMain
    {
        static void Main(string[] args)
        {
            Demo demo = new Demo();
            demo.Name();
            demo.Email();
        }
    }
}
