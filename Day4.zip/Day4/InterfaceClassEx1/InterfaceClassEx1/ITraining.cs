﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceClassEx1
{
    internal interface ITraining
    {
        void Name();
        void Email();
    }
}
