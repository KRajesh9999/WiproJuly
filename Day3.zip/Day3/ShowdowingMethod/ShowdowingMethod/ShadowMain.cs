﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShowdowingMethod
{
    internal class ShadowMain
    {
        static void Main(string[] args)
        {
            new Second().Show();
        }
    }
}
